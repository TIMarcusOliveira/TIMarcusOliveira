a = 1
b = 3
console.log(a + b)