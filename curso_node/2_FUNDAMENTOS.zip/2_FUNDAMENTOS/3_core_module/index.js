const path = require('path');

const extension = path.extname("arquivo.php")
                //nome da extensão
console.log(extension)