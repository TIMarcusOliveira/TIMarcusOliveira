import soma from './meu_modulo.mjs'

soma(3, 8)
soma(2, 3)