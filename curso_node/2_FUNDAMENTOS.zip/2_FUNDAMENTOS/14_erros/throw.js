x = 10

//ver se x é numero

if(!Number.isInteger(x)){
    throw new Error("O valor de X não é um número inteiro")
}

console.log("Continuando")