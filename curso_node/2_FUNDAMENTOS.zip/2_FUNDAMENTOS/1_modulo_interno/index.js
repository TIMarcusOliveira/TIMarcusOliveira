const meuModulo = require('./meu_modulo');
const soma = meuModulo.soma

soma(2, 3)
soma(5, 10)